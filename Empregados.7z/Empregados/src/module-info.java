/**
 * 
 */
/**
 * 
 */
module Empregados {
}